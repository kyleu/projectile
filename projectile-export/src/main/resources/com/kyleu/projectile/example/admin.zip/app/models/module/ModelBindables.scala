package models.module

object ModelBindables {
  /* Start model bindables */
  /* End model bindables */
}
