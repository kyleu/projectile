package util

object Config {
  final val projectId = "websocket"
  final val projectName = "websocket"
  final val metricsId = projectId
  final val pageSize = 100
}
