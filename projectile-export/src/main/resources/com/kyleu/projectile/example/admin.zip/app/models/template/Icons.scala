package models.template

object Icons {
  /* Start model icons */
  /* End model icons */

  /* Start thrift icons */
  /* End thrift icons */
}
