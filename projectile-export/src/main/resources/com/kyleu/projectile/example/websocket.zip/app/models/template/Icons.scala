package models.template

object Icons {
  /* Start model icons */
  /* Projectile export section [websocket] */
  val noteRow = "fa-code"
  val oauth2InfoRow = "fa-beer"
  val passwordInfoRow = "fa-hand-pointer-o"
  val systemUserRow = "fa-bell-o"
  /* End model icons */
}
