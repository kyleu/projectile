package models.template

import com.kyleu.projectile.models.menu.NavMenu

object ComponentMenu {
  val menu: Seq[NavMenu] = Seq(
    /* Start component menu items */
    /* End component menu items */
  )
}
